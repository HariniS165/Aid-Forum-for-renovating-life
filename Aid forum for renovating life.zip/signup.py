from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import pymysql
def reg():
    email = user_name.get()
    password = pass_word.get()
    number = phone_number.get()
    
    
    
    # Insert the user's information into the database
    sql = "INSERT INTO users (email, password, number) VALUES (%s, %s, %s)"
    val=(email,password,number)
    try:
        cur.execute(sql,val)
        con.commit()
        messagebox.showinfo('Success',"Signup successfully")
    except:
        messagebox.showinfo("Error","Can't add data into Database")
    
    # Clear the form fields
    user_name.delete(0, END)
    pass_word.delete(0, END)
    phone_number.delete(0, END)

    root.destroy()


def register():
    global user_name,pass_word,phone_number,Canvas1,userTable,con,cur
    root = Tk()
    root.title("Registration Form")
    root.geometry("400x300")

    mypass = "root"
    mydatabase="db"

    con = pymysql.connect(host="localhost",user="root",password=mypass,database=mydatabase)
    cur = con.cursor()
    userTable="users"

    Canvas1 = Canvas(root)
    
    Canvas1.config(bg="#ff6e40")
    Canvas1.pack(expand=True,fill=BOTH)
        
    headingFrame1 = Frame(root,bg="#FFBB00",bd=5)
    headingFrame1.place(relx=0.25,rely=0.1,relwidth=0.5,relheight=0.13)

    headingLabel = Label(headingFrame1, text="Signup", bg='black', fg='white', font=('Courier',15))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)


    labelFrame = Frame(root,bg='black')
    labelFrame.place(relx=0.1,rely=0.4,relwidth=0.8,relheight=0.4)
        
    
    lb1 = Label(labelFrame,text="Email", bg='black', fg='white')
    lb1.place(relx=0.05,rely=0.2, relheight=0.08)
        
    user_name = Entry(labelFrame)
    user_name.place(relx=0.3,rely=0.2, relwidth=0.62, relheight=0.08)
        
    
    lb2 = Label(labelFrame,text="Password", bg='black', fg='white')
    lb2.place(relx=0.05,rely=0.35, relheight=0.08)
        
    pass_word = Entry(labelFrame)
    pass_word.place(relx=0.3,rely=0.35, relwidth=0.62, relheight=0.08)
        
    
    lb3 = Label(labelFrame,text="PhoneNumber", bg='black', fg='white')
    lb3.place(relx=0.05,rely=0.50, relheight=0.08)
        
    phone_number = Entry(labelFrame)
    phone_number.place(relx=0.3,rely=0.50, relwidth=0.62, relheight=0.08)
        
    
    SubmitBtn = Button(root,text="Register",bg='#d1ccc0', fg='black',command=reg)
    SubmitBtn.place(relx=0.28,rely=0.9, relwidth=0.18,relheight=0.08)
    
    quitBtn = Button(root,text="Quit",bg='#f7f1e3', fg='black', command=root.destroy)
    quitBtn.place(relx=0.53,rely=0.9, relwidth=0.18,relheight=0.08)
    
    root.mainloop()
