from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import pymysql

def req():
    
    name=person_name.get()
    phone_number=contact_number.get()
    address=add_ress.get()
    item=item_want.get()
    on_behalf=on_behalf_of.get()
    
    sql = "INSERT INTO request (name, number, address, item, on_behalf) VALUES (%s, %s, %s, %s, %s)"
    val=(name,phone_number,address,item,on_behalf)
    try:
        cur.execute(sql,val)
        con.commit()
        messagebox.showinfo('Success',"Your request has been placed, we will contact you for further process...")
    except:
        messagebox.showinfo("Error","Can't add data into Database")
    

    root.destroy()
    
def request(): 
    
    global person_name,contact_number,add_ress,item_want,on_behalf_of,Canvas1,con,cur,reqTable,root
    
    root = Tk()
    root.title("Request")
    root.minsize(width=400,height=400)
    root.geometry("600x500")

    # Add your own database name and password here to reflect in the code
    mypass = "root"
    mydatabase="db"

    con = pymysql.connect(host="localhost",user="root",password=mypass,database=mydatabase)
    cur = con.cursor()

    # Enter Table Names here
    reqTable = "contacts" # Book Table

    Canvas1 = Canvas(root)
    
    Canvas1.config(bg="#EECBAD")
    Canvas1.pack(expand=True,fill=BOTH)
        
    headingFrame1 = Frame(root,bg="#FFBB00",bd=5)
    headingFrame1.place(relx=0.25,rely=0.1,relwidth=0.5,relheight=0.13)

    headingLabel = Label(headingFrame1, text="Request", bg='black', fg='white', font=('Courier',15))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)


    labelFrame = Frame(root,bg='black')
    labelFrame.place(relx=0.1,rely=0.4,relwidth=0.8,relheight=0.4)
        
    
    lb1 = Label(labelFrame,text="Name", bg='black', fg='white')
    lb1.place(relx=0.05,rely=0.2, relheight=0.08)
        
    person_name = Entry(labelFrame)
    person_name.place(relx=0.3,rely=0.2, relwidth=0.62, relheight=0.08)
        
    
    lb2 = Label(labelFrame,text="Contact Number", bg='black', fg='white')
    lb2.place(relx=0.05,rely=0.35, relheight=0.08)
        
    contact_number = Entry(labelFrame)
    contact_number.place(relx=0.3,rely=0.35, relwidth=0.62, relheight=0.08)
        
    
    lb3 = Label(labelFrame,text="Address", bg='black', fg='white')
    lb3.place(relx=0.05,rely=0.50, relheight=0.08)
        
    add_ress = Entry(labelFrame)
    add_ress.place(relx=0.3,rely=0.50, relwidth=0.62, relheight=0.08)
    
    lb4 = Label(labelFrame,text="Item", bg='black', fg='white')
    lb4.place(relx=0.05,rely=0.70, relheight=0.08)
        
    item_want = Entry(labelFrame)
    item_want.place(relx=0.3,rely=0.70, relwidth=0.62, relheight=0.08)
    
    lb5 = Label(labelFrame,text="For ", bg='black', fg='white')
    lb5.place(relx=0.05,rely=0.90, relheight=0.08)
        
    on_behalf_of = Entry(labelFrame)
    on_behalf_of.place(relx=0.3,rely=0.90, relwidth=0.62, relheight=0.08)
        
    #Submit Button
    SubmitBtn = Button(root,text="SUBMIT",bg='#d1ccc0', fg='black',command=req)
    SubmitBtn.place(relx=0.28,rely=0.9, relwidth=0.18,relheight=0.08)
    
    quitBtn = Button(root,text="Quit",bg='#f7f1e3', fg='black', command=root.destroy)
    quitBtn.place(relx=0.53,rely=0.9, relwidth=0.18,relheight=0.08)
    
    root.mainloop()
