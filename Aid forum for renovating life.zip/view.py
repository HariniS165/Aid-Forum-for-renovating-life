from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import pymysql
from attire import *
from books import *
from others import *
# Add your own database name and password here to reflect in the code
mypass = "root"
mydatabase="db"

con = pymysql.connect(host="localhost",user="root",password=mypass,database=mydatabase)
cur = con.cursor()

def View(): 
    
    root = Tk()
    root.title("Aid Forum for Renovating Life")
    root.minsize(width=400,height=400)
    root.geometry("600x500")

    Canvas1 = Canvas(root) 
    Canvas1.config(bg="#12a4d9")
    Canvas1.pack(expand=True,fill=BOTH)
    headingFrame1 = Frame(root,bg="#FFBB00",bd=5)
    headingFrame1.place(relx=0.2,rely=0.1,relwidth=0.6,relheight=0.16)
    headingLabel = Label(headingFrame1, text="View", bg='black', fg='white', font=('Courier',12))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)


    btn1 = Button(root,text="Attire",bg='black', fg='white', command=dress)
    btn1.place(relx=0.28,rely=0.4, relwidth=0.45,relheight=0.1)
    btn2 = Button(root,text="Books",bg='black', fg='white', command=books)
    btn2.place(relx=0.28,rely=0.5, relwidth=0.45,relheight=0.1)
    btn3 = Button(root,text="Others",bg='black', fg='white', command=others)
    btn3.place(relx=0.28,rely=0.6, relwidth=0.45,relheight=0.1)
    quitBtn = Button(root,text="Quit",bg='#f7f1e3', fg='black', command=root.destroy)
    quitBtn.place(relx=0.4,rely=0.9, relwidth=0.18,relheight=0.08)
    root.mainloop()
