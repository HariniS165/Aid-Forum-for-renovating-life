use db;
insert into dress(Product_id, Name, Gender, Status) values(101, 'Chuditar', 'Female', 'Avail');